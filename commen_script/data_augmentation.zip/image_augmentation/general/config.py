#!usr/bin/env python3
# -*- coding: UTF-8 -*-
IMAGE_FORMAT = r"jpg|jpeg|png|JPG|JPEG|PNG"