from xl_tool.xl_io import file_scanning
import os
import shutil
from random import shuffle
from PIL import Image
from image_augmentation.transform.voc import Text2XML
from xl_tool.augmentation.image.general.blending import ObjectReplaceBlend
real_path = r"G:\food_dataset\1_真实场景\0_已标框"
# path2 = r"G:\food_dataset\7_增强图片\experienment\single_direct"
real_target_path = r"G:\food_dataset\7_增强图片\experienment2\real_annonation_250"
object_paths = r"G:\food_dataset\5_抽取目标\待筛选_网络"
# real_target = r"G:\food_dataset\7_增强图片\experienment\direct_blend_800"
aug_path = r"G:\food_dataset\7_增强图片\experienment2\replace_blend_800"

def copy_to_dataset(path,target):
    for d in os.listdir(path):
        if d not in ['pumpkin_block',
                          'chives',
                          'whole_chicken',
                          'chicken_breast',
                          'chicken_feet',
                          'chicken_brittle_bone',
                          'ribs',
                          'hamburger_steak',
                          'lamb_chops',
                          'prawn',
                          'salmon',
                          'oyster',
                          'scallop',
                          'peanut']:
            continue
        files = file_scanning(f"{path}/{d}", file_format="jpg|jpe",sub_scan=True)
        shuffle(files)
        os.makedirs(f"{target}/train/{d}",exist_ok=True)
        os.makedirs(f"{target}/val/{d}", exist_ok=True)
        for i, file in enumerate(files[:200]):
            t = f"{target}/train/{d}" if i<150 else f"{target}/val/{d}"
            shutil.copy(file, f"{t}/{os.path.basename(file)}")
            try:
                shutil.copy(file.replace("jpg","xml"), f"{t}/{os.path.basename(file).replace('jpg','xml')}")
            except:
                pass




copy_to_dataset(real_path,real_target_path,aug_path)

def replace_augmentation(object_path, real_a_path, object_classes):

    blender = ObjectReplaceBlend()
    for d in [i for i in os.listdir(f"{real_a_path}") if i in object_classes]:
        files = file_scanning(f"{real_a_path}/{d}","jpg",sub_scan=True)
        single_object = f"{object_paths}/{d}"
        os.makedirs(f"{aug_path}/{d}",exist_ok=True)
        object_images = [Image.open(i) for i in file_scanning(single_object, "jpg")]
        object_images = [i for i in object_images if (i.size[0]>8 and i.size[1]>8)]
        aspects = [i.size[0] / i.size[1] for i in object_images]
        try:
            object_images, aspects = zip(*sorted(zip(object_images, aspects), key=lambda x: x[1]))
        except Exception as e:
            print("dddddddddddddd")
            pass
        for image_file in files:
            xml_folder = r"Food2019"
            xml_source = 'FoodDection'
            xml_file = image_file.replace("jpg", "xml")
            try:
                aug_image,boxes = blender.blending_one_image(image_file, object_images, aspects, xml_file, random_choice=False,aspect_jump=1.0)
            except:
                print("------------------")
                blender.blending_one_image(image_file, object_images, aspects, xml_file, random_choice=False,
                                           aspect_jump=1.0)
            save_img = f"{aug_path}/{t}/{d}/{'replace_aug_'+os.path.basename(image_file)}"
            aug_image.save(save_img)
            text2xml = Text2XML()
            objects_info = [[d] + coordinate for coordinate in boxes]
            boximg_file = os.path.basename(save_img)
            xml = text2xml.get_xml(xml_folder, boximg_file, boximg_file, xml_source, aug_image.size, objects_info)
            # boxxml_file =
            # aug_image.save(cat_aug_path + "/" + boximg_file)
            with open(save_img.replace("jpg", "xml") , "w") as f:
                f.write(xml)
# copy_to_dataset(path2,real_target)


# import random
# path = r"G:\food_dataset\7_增强图片\temp\single_direct"
# dirs = [i for i in os.listdir(path) if i not in {"val", "train"}]
# target = r"G:\food_dataset\7_增强图片\temp\spilited_dataset"
# train = target + "/train"
# val = target + "/val"
# split = 0.8
# seed =10
# max_num = 1500
# for d in dirs:
#     class_ = d
#     class_dir = f"{path}/{class_}"
#     xml_files = file_scanning(class_dir, full_path=True,sub_scan=True,file_format="xml")[:max_num]
#     random.seed(seed)
#     shuffle(xml_files)
#     split_index = int(0.8 * len(xml_files))
#     os.makedirs(f"{train}/{class_}",exist_ok=True)
#     os.makedirs(f"{val}/{class_}", exist_ok=True)
#     for i,xml_file in enumerate(xml_files):
#         if os.path.exists(xml_file.replace("xml","jpg")) or os.path.exists(xml_file.replace("xml","jpeg")):
#             image_file = xml_file.replace("xml", "jpg")
#             if i<split_index:
#
#                 shutil.copy(xml_file, f"{train}/{class_}/{os.path.basename(xml_file)}")
#                 shutil.copy(image_file, f"{train}/{class_}/{os.path.basename(image_file)}")
#             else:
#                 shutil.copy(xml_file, f"{val}/{class_}/{os.path.basename(xml_file)}")
#                 shutil.copy(image_file, f"{val}/{class_}/{os.path.basename(image_file)}")